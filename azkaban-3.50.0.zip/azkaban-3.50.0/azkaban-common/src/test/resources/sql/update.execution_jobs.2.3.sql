INSERT INTO properties (name, value, modified_time, type) VALUES ('test4', 'value1', 0, 99);
