ALTER TABLE project_events
  MODIFY COLUMN message VARCHAR(512);
