INSERT INTO properties (name, value, modified_time, type) VALUES ('test', 'value1', 0, 99);
